<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('curriculums', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->string('description');
            $table->string('module_id')->references('id')->on('modules');
            $table->unsignedBigInteger('course_id')->refrence('id')->on('courses')->onDelete('cascade');
            $table->unsignedBigInteger('year_id');
            $table->unsignedBigInteger('user_id');
            $table->timestamps();
        });

    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('curriculums');
    }
};
