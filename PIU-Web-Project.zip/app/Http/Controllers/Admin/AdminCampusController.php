<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Campus;
use Illuminate\validation\Rule;

class AdminCampusController extends Controller
{
    public function index()
    {
       return view('admin.campus.index',[
        'campuses' => Campus::all()
       ]);
    }

    public function create()
    {
        return view('admin.campus.create');
    }

    public function store(Request $request)
    {
       $formData = request()->validate([
            'name' => ['required',Rule::unique('campuses','name')],
            'description' => 'required',
            'location' => 'required',
        ]);

        if($request->hasFile('image')){
            $filePath = $request->file('image')->store('campuses','public');
            $formData['image'] = $filePath;
        };

        Campus::create($formData);

        return redirect('/admin/campus');
    }

    public function edit($id)
    {
        $campus = Campus::where('id',$id)->firstOrFail();
       return view('admin.campus.edit',[
        'campus' => $campus
       ]);
    }

    public function update(Request $request, $id)
    {
        $campus = Campus::where('id',$id)->firstOrFail();
       $formData = request()->validate([
            'name' => ['required',Rule::unique('campuses','name')],
            'description' => 'required',
            'location' => 'required',
        ]);

        if($request->hasFile('image')){
            $filePath = $request->file('image')->store('campuses','public');
            $formData['image'] = $filePath;
        };

        $campus->update($formData);

        return redirect('/admin/campus');
    }

    public function destroy($id)
    {
        $campus = Campus::where('id',$id)->firstOrFail();
        $campus->delete();

        return back();
    }

    public function uploadImage(Request $request)
    {
        if($request->hasfile('upload')){
            $originName = $request->file('upload')->getClientOriginalName();
            $fileName = pathinfo($originName, PATHINFO_FILENAME);
            $extension = $request->file('upload')->getClientOriginalExtension();
            $fileName = $fileName . '_'. time(). '.'.$extension;
            $request->file('upload')->move(public_path('campus'),$fileName);
            $CKEditorFuncNum = $request->input('CKEditorFuncNum');
            $url = asset('campus/'.$fileName);
            $msg = 'Image successfully uploaded';
            $response = "<script>window.parent.CKEDITOR.tools.callFunction($CKEditorFuncNum, '$url', '$msg')</script>"; 
            // return responce()->json(['fileName' => $filename, 'uploaded'=>1, 'url'=>$url]);
            @header('Content-type: text/html; charset=utf-8'); 
            echo $response;
        }
    }
}