<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\Contact;
use App\Mail\ContactFormMail;
use Illuminate\Support\Facades\Mail;

class ContactController extends Controller
{
    public function store(Request $request)
    {
        $formData = request()->all();
        // return response()->json($formData);

        $recaptchaSecret = env('NOCAPTCHA_SECRET');
        $recaptchaResponse = $request->input('recaptcha');

        $client = new Client();

        $response = $client->post('https://www.google.com/recaptcha/api/siteverify', [
        'form_params' => [
            'secret' => $recaptchaSecret,
            'response' => $recaptchaResponse
        ]
    ]);

    $responseBody = json_decode((string) $response->getBody());

    if (!$responseBody->success) {
        return response()->json(['recaptcha' => 'reCAPTCHA verification failed.'], 422);
    }


        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'email' => 'required|email',
            'phone' => 'required',
            'country'=> 'required',
            'message' => 'required',
            'reCapt' => 'required|captcha',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        $data = Contact::create([
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            'country'=> $request->country,
            'message' => $request->message
        ]);

        // Sending email
        Mail::to('piu.webdeveloper@gmail.com')->send(new ContactFormMail($data));

        return response()->json(['message' => 'Your message has been sent successfully. Thank you for contacting us.'], 200);
    }
}